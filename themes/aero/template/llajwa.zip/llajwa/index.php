<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <title>Portada • Llajwa Club</title>
      <meta name="author" content="Alvaro Trigo Lopez" />
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="fullPage fixed header and footer." />
      <meta name="keywords"  content="fullpage,jquery,demo,screen,fixed, header,footer, absolute, positioned,css" />
      <meta name="Resource-type" content="Document" />
      <link rel="shortcut icon" href="imgs/favicon.ico">
      <link rel="stylesheet" type="text/css" href="../dist/fullpage.css" />
      <link rel="stylesheet" href="css/bulma.css">
      <link rel="stylesheet" href="css/aero.css">
      <link rel="stylesheet" type="text/css" href="css/fonts.css" />
      <link rel='stylesheet' href='//unpkg.com/plyr@3/dist/plyr.css'>
      <link rel="stylesheet" href="css/player.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
      <!--[if IE]>
      <script type="text/javascript">
         var console = { log: function() {} };
      </script>
      <![endif]-->
   </head>
   <body>
      <div id="fullpage">
         <div class="section" id="section0">
            <div class="content">
               <div class="columns">
                  <div class="column is-8 is-offset-2">
                     <img src="imgs/logo.svg" class="aeroImg50ph">
                     <h2 class="is-size-2-fullhd is-size-3-widescreen is-size-4-desktop is-size-5-touch is-size-5-tablet is-size-6-mobile">SOLUCIONES CORPORATIVAS INTELIGENTES</h2>
                     <p>¡Ahora pruebe con llajwa!</p>
                     <p>
                        <a href="https://m.me/LlajwaClub" target="_blank" class="button is-danger is-outlined  is-medium">
                        <i class="fab fa-facebook-messenger"></i> &nbsp; Iniciar chat
                        </a>                        
                     </p>
                     <span class="scroll-btn">
                     <a href="#">
                     <span class="mouse">
                     <span>
                     </span>
                     </span>
                     </a>
                     </span>
                  </div>
               </div>
            </div>
         </div>
         <div class="section has-background-dark has-text-white" id="section1">
            <div class="slide" id="slide1">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success">Desarrollo <br>Web & Móvil</h1>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h2 class="is-size-2-fullhd is-size-2-widescreen is-size-2-desktop is-size-3-touch is-size-3-tablet is-size-4-mobile has-text-success">Presencia con futuro</h2>
                        <p>Su presencia digital en la nube es el factor relevante en estrategia de marca para el futuro.<br><br>
                        <h3>¿Lo sabía?</h3>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide3">
               <div class="content">
                  <div class="column is-10 is-offset-1">
                     <div class="columns is-mobile is-multiline">
                        <div class="column is-6">
                           <div>
                              <i class="fas fa-mobile aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-2-desktop is-size-4-touch is-size-4-tablet is-size-4-mobile has-text-success"></i> 
                              <h4>Moderno</h4>
                              <p class="has-text-grey-lighter">La tecnología evoluciona a cada hora, nos encanta aprender.</p>
                           </div>
                        </div>
                        <div class="column is-6">
                           <div>
                              <i class="fas fa-rocket aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-2-desktop is-size-4-touch is-size-4-tablet is-size-4-mobile has-text-success"></i>
                              <h4>Potente</h4>
                              <p class="has-text-grey-lighter">La potencia detrás de la nube antecede el éxito y hace la diferencia.</p>
                           </div>
                        </div>
                        <div class="column is-6">
                           <div>
                              <i class="fas fa-frog aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-2-desktop is-size-4-touch is-size-4-tablet is-size-4-mobile has-text-success"></i>
                              <h4>Flexible</h4>
                              <p class="has-text-grey-lighter">Es la tecnología la que debe adaptarse a su organización, no al revés.</p>
                           </div>
                        </div>
                        <div class="column is-6">
                           <div>
                              <i class="fas fa-level-up-alt aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-2-desktop is-size-4-touch is-size-4-tablet is-size-4-mobile has-text-success"></i>
                              <h4>Escalable</h4>
                              <p class="has-text-grey-lighter">Los edificios digitales se construyen con ingeniería y cimientos sólidos.</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide4">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-3-fullhd is-size-3-widescreen is-size-4-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">
                        <p class="">Posiblemente esté pensado en desarrollar 
                           su estrategia digital de forma seria. El mejor enfoque comienza con seleccionar un cocinero 
                           experimentado con los ingredientes correctos. Para nosotros, el proceso comienza escuchándolo, planificando 
                           y analizando sus necesidades según los objetivos de su marca.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide5">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <div class="fa-30x">
                           <i class="fas fa-cog fa-spin aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                        </div>
                        <div>
                           Aprendemos, entrenamos y aplicamos lo mejor de la tecnología de forma eficiente.
                        </div>
                        <div class='carousel carousel-animated carousel-animate-slide' data-size="3" data-autoplay="true" data-delay="2000">
                           <div class='carousel-container'>
                              <div class='carousel-item is-active'>
                                 <img src="imgs/icono-angular.png" class="aeroImg150v">
                                 <p>Angular</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-aws.png" class="aeroImg150v">
                                 <p>AWS</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-docker.png" class="aeroImg150v">
                                 <p>Docker</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-firebase.png" class="aeroImg150v">
                                 <p>Firebase</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-google.png" class="aeroImg150v">
                                 <p>Google Cloud</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-ionic.png" class="aeroImg150v">
                                 <p>Ionic</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-java.png" class="aeroImg150v">
                                 <p>Java</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-laravel.png" class="aeroImg150v">
                                 <p>Laravel</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-mongo.png" class="aeroImg150v">
                                 <p>MongoDB</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-node.png" class="aeroImg150v">
                                 <p>Node.js</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-react.png" class="aeroImg150v">
                                 <p>React Native</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-swift.png" class="aeroImg150v">
                                 <p>Swift</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-vue.png" class="aeroImg150v">
                                 <p>Vue.js</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/icono-webpack.png" class="aeroImg150v">
                                 <p>Webpack</p>
                              </div>
                           </div>
                           <div class="carousel-navigation is-centered">
                              <div class="carousel-nav-left">
                                 <i class="fa fa-chevron-left" aria-hidden="true"></i>
                              </div>
                              <div class="carousel-nav-right">
                                 <i class="fa fa-chevron-right" aria-hidden="true"></i>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide6">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-3-fullhd is-size-3-widescreen is-size-4-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">
                        <p>
                           Se trata de números, y nos referimos a números relevantes; sabemos lo que se necesita para construir, distribuir y medir, usamos herramientas digitales efectivas,
                           diseñadas para aumentar el alcance de su marca, atraer clientes potenciales
                           y tener un impacto comercial con resultados.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide7">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h3>Hecho a medida, apto para crecer, es picante...</h3>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide has-background-link has-text-light" id="slide9">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">Asesoría</h1>
                        <p>
                           Contacte con nosotros y le asignameros un experto que analice su caso y le brinde opciones.
                        </p>
                        <a href="https://m.me/LlajwaClub" target="_blank" class="button is-white is-outlined  is-large">
                        <i class="fab fa-facebook-messenger"></i> &nbsp; Iniciar chat
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="section has-background" id="section2">
            <div class="slide" id="slide1" style="overflow:hidden;">
               <div id="clouds">
                  <div class="cloud x1"></div>
                  <!-- Time for multiple clouds to dance around -->
                  <div class="cloud x2"></div>
                  <div class="cloud x3"></div>
                  <div class="cloud x4"></div>
                  <div class="cloud x5"></div>
               </div>
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link">Cloud Computing</h1>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h2 class="is-size-2-fullhd is-size-2-widescreen is-size-2-desktop is-size-3-touch is-size-3-tablet is-size-4-mobile has-text-link">Ayudamos a crecer y escalar</h2>
                        <p><b>Ofrecemos potencia de cómputo, almacenamiento y entrega de 
                           contenidos. </b><br><br>Desarrolle aplicaciones sofisticadas, flexibles y fiables en nuestra nube.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide3">
               <div class="content">
                  <div class="column is-8 is-offset-2">
                     <div class="columns is-mobile is-multiline is-desktop">
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-server aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4 class="has-text-dark">Shared Hosting</h4>
                              <p>Nuestro alojamiento web incluye dominio, cPanel, SSL y paquetes de potencia que lo hacen único.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fab fa-cloudversify aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4 class="has-text-dark">Cloud Hosting</h4>
                              <p>Distribuya los recursos sus web apps a un grupo de servidores de forma flexible, escale en tiempo real.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-database aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4 class="has-text-dark">CDN</h4>
                              <p>Nuestro CDN almacena su contenido estático y lo distribuye a más velocidad mientras reduce la latencia.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-code aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4 class="has-text-dark">VPS</h4>
                              <p>Cómputo escalable con capacidades adicionales de monitoreo y seguridad para aplicaciones de producción.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-laptop-code aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4 class="has-text-dark">Máquinas virtuales</h4>
                              <p>Virtualización de máquinas Linux y Windows, aptos para una variada gama de soluciones informáticas.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="far fa-play-circle aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4 class="has-text-dark">Streaming</h4>
                              <p>Modernas plataformas y herramientas de distribución de audio y vídeo en vivo a través de múltiples canales.</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide4">
               <div class="content">
                  <div class="column is-10 is-offset-1 ">
                     <div class="columns is-mobile is-multiline is-centered">
                        <div class="column">
                           <div class="">
                              <i class="fas fa-shopping-cart aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4>Llajwa Marketplace</h4>
                              <div class="column is-6 is-offset-3 has-text-centered">
                                 <p>
                                    Servicios digitales adecuados al mercado boliviano.
                                 </p>
                              </div>
                              <a href="https://marketplace.llajwa.club/?ref=web-alojamientovip.com" target="_blank" class="button is-link"><span class="icon is-medium"><i class="fas fa-globe-americas"></i></span>&nbsp; marketplace.llajwa.club</a>                                 
                              <a href="https://m.me/llajwaClub/" target="_blank" class="button is-link is-outlined"><span class="icon is-medium "><i class="fab fa-facebook-messenger"></i></span></a>
                              <a href="https://api.whatsapp.com/send?phone=59177954277&text=Solicitud%20de%20soporte%20para%20Llajwa%20Marketplace." target="_blank" class="button is-link is-outlined"><span class="icon is-medium"><i class="fab fa-whatsapp"></i></span></a>                             
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide5">
               <div class="content">
                  <div class="column is-10 is-offset-1 ">
                     <div class="columns is-mobile is-multiline">
                        <div class="column">
                           <div class="">
                              <i class="fas fa-cloud aeroFeaturesIcon is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-link"></i>
                              <h4>Alojamiento VIP</h4>
                              <div class="column is-6 is-offset-3 has-text-centered">
                                 <p>
                                    Nuestra nueva agencia de tecnología, provee servicios a toda Latinoamérica.
                                 </p>
                              </div>
                              <a href="https://www.alojamiento.vip/?ref=web-alojamientovip.com" target="_blank" class="button is-link"><span class="icon is-medium"><i class="fas fa-globe-americas"></i></span>&nbsp; www.alojamiento.vip</a>                                 
                              <a href="https://m.me/llajwaClub/" target="_blank" class="button is-link is-outlined"><span class="icon is-medium "><i class="fab fa-facebook-messenger"></i></span></a>
                              <a href="https://api.whatsapp.com/send?phone=59177954277&text=Solicitud%20de%20soporte%20para%20Alojamiento.vip" target="_blank" class="button is-link is-outlined"><span class="icon is-medium"><i class="fab fa-whatsapp"></i></span></a>   
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide7">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h3>Accesible, confiable y asistido, es picante...</h3>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide has-background-link has-text-light" id="slide8">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">¿Preguntas?</h1>
                        <p>
                           No sea tímido, ¡nos encanta leer y escuchar!
                        </p>
                        <a href="https://m.me/LlajwaClub" target="_blank" class="button is-white is-outlined  is-large">
                        <i class="fab fa-facebook-messenger"></i> &nbsp; Inicie un chat
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="section" id="section3">
            <div class="slide aeroBgImgFull" id="slide1" style="background-image: url('imgs/bg-sheep.jpg');">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-light">Diseño</h1>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h2 class="is-size-2-fullhd is-size-2-widescreen is-size-2-desktop is-size-3-touch is-size-3-tablet is-size-4-mobile has-text-success">Elegancia simple</h2>
                        <p>Juntamos la creatividad de nuestros diseñadores mientras maximizamos la experiencia de usuario en un ámbito minimalista inteligente.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide3">
               <div class="content">
                  <div class="column is-8 is-offset-2">
                     <div class="columns is-mobile is-multiline is-desktop">
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-pencil-ruler aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success"></i>
                              <h4 class="has-text-dark">Minimalista</h4>
                              <p>Transmitimos información sólida a través de interfaces simples.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-heart aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success"></i>
                              <h4 class="has-text-dark">UX</h4>
                              <p>Nos concentramos en la satisfacción de experiencia de usuario.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-vector-square aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success"></i>
                              <h4 class="has-text-dark">Vectorial</h4>
                              <p>Diseño versatil, apto para todo fines digitales y físicos.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-camera aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success"></i>
                              <h4 class="has-text-dark">Fotográfico</h4>
                              <p>Potentes herramientas y desarrollamos técnicas de fotografía digital.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-rocket aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success"></i>
                              <h4 class="has-text-dark">Premium</h4>
                              <p>Distribuimos diseño autores profesionales de todo el mundo.</p>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-robot aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-success"></i>
                              <h4 class="has-text-dark">Moderno</h4>
                              <p>Desarrollo responsivo, modular, escalable y colaborativo.</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide4">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-3-fullhd is-size-3-widescreen is-size-4-desktop is-size-5-touch is-size-5-tablet is-size-6-mobile">
                        <p>La entrega de su marca a través de los criterios de diseño
                           es fundamental y debe ser impulsado por un objetivo claro, bajo una comprensión clara para sus clientes.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide5">
               <div class="content">
                  <h1 class="has-text-success">Casos de aplicación</h1>
                  <div class="columns">
                     <div class="column is-8 is-offset-2">
                        <div class='carousel carousel-animated carousel-animate-slide' data-size="3" data-autoplay="true" data-delay="2000">
                           <div class='carousel-container'>
                              <div class='carousel-item is-active'>
                                 <img src="imgs/design-pencil.png" class="aeroImg150v">
                                 <p>Mockups</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-type.png" class="aeroImg150v">
                                 <p>Tipografía</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-colours.png" class="aeroImg150v">
                                 <p>Ilustraciones</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-layers.png" class="aeroImg150v">
                                 <p>Maquetación CSS3</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-monitor.png" class="aeroImg150v">
                                 <p>Plantillas Web</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-drawing-tablet.png" class="aeroImg150v">
                                 <p>Dibujo digital</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-printer.png" class="aeroImg150v">
                                 <p>Diseño para impresión</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-vectors.png" class="aeroImg150v">
                                 <p>Diseño vectorial</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-camera.png" class="aeroImg150v">
                                 <p>Fotografía digital</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-selection.png" class="aeroImg150v">
                                 <p>Iconografía</p>
                              </div>
                              <div class='carousel-item'>
                                 <img src="imgs/design-cmyk.png" class="aeroImg150v">
                                 <p>Teoría del color</p>
                              </div>
                           </div>
                           <div class="carousel-navigation is-centered">
                              <div class="carousel-nav-left">
                                 <i class="fa fa-chevron-left" aria-hidden="true"></i>
                              </div>
                              <div class="carousel-nav-right">
                                 <i class="fa fa-chevron-right" aria-hidden="true"></i>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide6">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h3>Diseño simple, con inteligencia... es picante.</h3>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide has-background-link has-text-light" id="slide7">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">¿Preguntas?</h1>
                        <p>
                           Nuestros diseñadores están ansiosos de usar su talento para para usted.
                        </p>
                        <a href="https://m.me/LlajwaClub" target="_blank" class="button is-white is-outlined  is-large">
                        <i class="fab fa-facebook-messenger"></i> &nbsp; Iniciar chat
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="section has-background-warning has-text-dark" id="section4">
            <div class="slide" id="slide1">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">Marketing & Publicidad</h1>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-3-fullhd is-size-3-widescreen is-size-4-desktop is-size-5-touch is-size-5-tablet is-size-6-mobile">
                        <p class=""><i class="fas fa-skull-crossbones"></i> Posiblemente su presencia en Internet esté muerta. 
                           Aun las marcas más poderosas del mundo están obligadas a generar campañas publicitarias digitales para hacerse notar y crecer. 
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide aeroBgImgFull has-background-dark" id="slide3" style="background-image: url('imgs/bg-dead.png');">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-4">
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>Sin planificación y estrategia</b><br>
                                 Es posible que tenga una página en Facebook y/o un sitio web, incluso es posible que le estén ayudando a vender. 
                                 Esto no necesariamente significa que esté explotando la tecnología para lograr sus sueños. 
                                 <br><i class="fas fa-skull"></i> Sin análisis, planificación, estrategia y objetivos claros... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>En manos de parientes, diseñadores o marqueteros</b><br>
                                 Poner su negocio digital en personas inmersas en un fragmento de la tecnología digital es un frecuente error. Conformarse con presencia en línea, que sus contenidos visualmente luzcan bien o
                                 logre ciertos contenidos virales no demuestran que sus proyectos sean realmente sólidos.
                                 <br><i class="fas fa-skull"></i> Sin expertos reales ni experiencia apoyada en el conocimiento científico... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>Segmentación de nicho no identificado</b><br>
                                 Es posible que sus productos o servicios se vendan bien de forma tradicional. Sin embargo la nube funciona de otra manera, tratar de vender su producto a todo el mundo es un error, 
                                 aun las grandes empresas en línea seleccionan previamente dónde invertir a la hora de promocionar, lo que le acerca a lograr más ventas en línea. 
                                 <br><i class="fas fa-skull"></i> Si no conoce a sus segmentos de clientes potenciales para cada producto o servicio... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>Sin lectura de los números</b><br>
                                 Aunque un sitio web no parezca más que un folleto o catálogo, el funcionamiento de un sitio web es sumamente complejo y de qué forma sus visitantes interactúan con él 
                                 es más complejo todavía; afortunadamente existen potentes servicios en línea que logran medir y ordenar esta abundante información a través de informes técnicos legibles y 
                                 de los que es importante tomar información para dirigir la estrategía.
                                 <br><i class="fas fa-skull"></i> Sin una lectura adecuada de la analítica web... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>¿Imagen o ventas?</b><br>
                                 Muchos negocios en Internet no están interesados en usar la tecnología como canal de ventas y solo quieren consolidar su marca digital, lo que puede estar bien;
                                 muchas empresas pretenden generar ventas a través de una imagen deficiente, muchos otros tienen buenos productos y una presencia apreciable, pero 
                                 no presentan sus ventajas de forma óptima. 
                                 <br><i class="fas fa-skull"></i> Si no tiene clara su filosofía en línea y no reconoce sus puntos débiles... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>Ads: ¿Gastando o invirtiendo?</b><br>
                                 Es muy simple iniciar una campaña en Google Ads o Facebook Ads, sin embargo el éxito para lograr establecer presupuestos de inversión bajos que realice 
                                 conversiones de rendimiento satisfactorias y permanentes en el tiempo depende de técnica y una parte de esta técnica depende de la naturaleza misma del negocio (lo que la hace única
                                 para cada tipo de negocio y/o producto o servicio) y del análisis de datos a través de herramientas especializadas.
                                 <br><i class="fas fa-skull"></i> Si no descifra las mejor técnica para desarrollar sus campaña publicitaria a través de anuncios... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                        <div class="card has-background-warning has-text-left">
                           <div class="card-content">
                              <div class="content">
                                 <b>La tecnología no hace magia</b><br>
                                 El problema frecuente de los emprendedores en línea, es creer que una vez que el sitio web y las redes sociales están en línea simplemente hay que sentarse a recibir los beneficios. 
                                 Todos los negocios en línea deben alimentarse, crecer y madurar: se dará cuenta que lo que hizo lo hizo bien cuando
                                 escale a que de forma tradicional jamás hubiera imaginado. Eso significa trabajo y afianzación.
                                 <br><i class="fas fa-skull"></i> Si su negocio no ha sido cimentado para desarrollar escalabilidad... <b>¡su negocio está muerto!</b>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide4">
               <div class="content">
                  <div class="column is-8 is-offset-2">
                     <h2>Cobertura efectiva</h2>
                     <div class="columns is-mobile is-multiline is-desktop">
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-ad aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                              <h4 class="has-text-dark">Ads</h4>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-bullhorn aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                              <h4 class="has-text-dark">Branding</h4>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-chart-area aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                              <h4 class="has-text-dark">Analytics</h4>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-pencil-alt aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                              <h4 class="has-text-dark">Storytelling</h4>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-thumbs-up aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                              <h4 class="has-text-dark">Engagement</h4>
                           </div>
                        </div>
                        <div class="column is-half-mobile is-half-tablet is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
                           <div>
                              <i class="fas fa-brain aeroFeaturesIconShort is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile"></i>
                              <h4 class="has-text-dark">UX</h4>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide5">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-3-fullhd is-size-3-widescreen is-size-4-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">
                        <p>
                           Ya sea creando un concepto de campaña o diseñando el material de marketing impactante, 
                           la estrategia debe seguir objetivos claros en periodos de tiempo razonables.
                           Analizar con los ojos de los clientes potenciales aseguran el retorno de la inversión.                           
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide has-background-dark has-text-light" id="slide6">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-3-fullhd is-size-3-widescreen is-size-4-desktop is-size-5-touch is-size-5-tablet is-size-6-mobile">
                        <h2>Facebook Baby</h2>
                        <div class="container" style="-webkit-box-shadow: 0px 0px 99px 13px rgba(0,0,0,1); -moz-box-shadow: 0px 0px 99px 13px rgba(0,0,0,1); box-shadow: 0px 0px 99px 13px rgba(0,0,0,1);">
                           <div id="player" data-plyr-provider="vimeo" data-plyr-embed-id="301399550"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide7">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h3>Publicidad y marketing persuasivo... es picante.</h3>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide has-background-link has-text-light" id="slide8">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">¿Dudas?</h1>
                        <p>
                           Nuestros publicistas pueden crear una estrategia de marketing digital para que su negocio se alimente de relevancia.
                        </p>
                        <a href="https://m.me/LlajwaClub" target="_blank" class="button is-white is-outlined  is-large">
                        <i class="fab fa-facebook-messenger"></i> &nbsp; Iniciar un chat
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="section has-text-light" id="section5">
            <div class="slide" id="slide1">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile has-text-light">Brand Builder</h1>
                        <div class="column is-8 is-offset-2 is-size-4-fullhd is-size-4-widescreen is-size-4-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">  
                           <br>
                           Construir o reconstruir su marca en Internet es posible <i class="fas fa-long-arrow-alt-right"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <h1 class="has-text-light">Descubrimos</h1>
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-5-fullhd is-size-5-widescreen is-size-5-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">  
                        A través de <a class="tooltip is-tooltip-multiline is-tooltip-warning" data-tooltip="Llajwa Platform es una plataforma en línea para interactuar con nuestros clientes de forma efectiva y ordenada." style="color: white; border-bottom: 1px dashed white"><b>Llajwa Platform</b></a> 
                        seleccionamos el protocolo apto para aprender de su empresa.
                     </div>
                  </div>
               </div>
               <ul class="steps has-content-centered has-gaps is-horizontal">
                  <li class="steps-segment is-active" >
                     <span class="steps-marker is-warning">1</span>
                  </li>
                  <li class="steps-segment">
                     <span class="steps-marker is-grey">2</span>
                  </li>
                  <li class="steps-segment">
                     <span class="steps-marker is-grey">3</span>
                  </li>
               </ul>
            </div>
            <div class="slide" id="slide3">
               <div class="content">
                  <h1 class="has-text-light">Creamos</h1>
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-5-fullhd is-size-5-widescreen is-size-5-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">  
                        Construimos un nuevo relato de marca o 
                        <a class="tooltip is-tooltip-multiline is-tooltip-warning" data-tooltip="El Brand Storytelling de una marca es la suma de su identidad corporativa y su reputación. Dicho de otro modo, es el resultado de aquello que una marca comunica sobre sí misma y la opinión que se forma la sociedad." style="color: white; border-bottom: 1px dashed white"><b>Brand Storytelling</b></a>,
                        que incluyen los factores de diferencia, la visión de la marca, los valores, 
                        el arquetipo, la línea de correa y el protocolo para el soporte; 
                        todo a través de canales digitales potentes y atractivos. 
                     </div>
                  </div>
               </div>
               <ul class="steps has-content-centered has-gaps is-horizontal">
                  <li class="steps-segment">
                     <span class="steps-marker is-warning">1</span>
                  </li>
                  <li class="steps-segment is-active">
                     <span class="steps-marker is-warning">2</span>
                  </li>
                  <li class="steps-segment">
                     <span class="steps-marker is-grey">3</span>
                  </li>
               </ul>
            </div>
            <div class="slide" id="slide4">
               <div class="content">
                  <h1 class="has-text-light">Distribuimos</h1>
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2 is-size-5-fullhd is-size-5-widescreen is-size-5-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">  
                        Inspirados en la confección de su nueva identidad digital, damos vida a su marca aplicando tecnología competente 
                        a través de canales apropiados para su organización (Webs, redes sociales, apps, etc.), un plan de lanzamiento 
                        y promoción para recolectar valor real para su marca.
                     </div>
                  </div>
               </div>
               <ul class="steps has-content-centered has-gaps is-horizontal">
                  <li class="steps-segment">
                     <span class="steps-marker is-warning">1</span>
                  </li>
                  <li class="steps-segment is-active">
                     <span class="steps-marker is-warning">2</span>
                  </li>
                  <li class="steps-segment">
                     <span class="steps-marker is-warning">3</span>
                  </li>
               </ul>
            </div>
            <div class="slide" id="slide5">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h1 class="has-text-light">¿Qué recibe?</h1>
                        <div class="column is-8 is-offset-2 has-text-left">
                           <p>
                              <i class="fas fa-check"></i> Diagnóstico inicial <span class="is-size-7 has-text-warning">¡Solicite gratis!</span><br>
                              <i class="fas fa-check"></i> Propuesta de desarrollo.<br>
                              <i class="fas fa-check"></i> Mockups y prototipos.<br>                                  
                              <i class="fas fa-check"></i> Desarrollo en la nube según propuesta. <span class="is-size-7">→ Webs, apps, etc.</span><br>                                    
                              <i class="fas fa-check"></i> Manual de marca.<br>  
                              <i class="fas fa-check"></i> Diseño/rediseño digital. <span class="is-size-7">→ Logotipo, redes sociales, material impreso, tarjetas de presentación.</span><br>
                              <i class="fas fa-check"></i> Manual de contenidos.<br>
                              <i class="fas fa-check"></i> Manual de estrategia publicitaria.<br>
                              <i class="fas fa-check"></i> Protocolo de atención al cliente.<br>                                      
                              <i class="fas fa-check"></i> Herramientas corporativas. <span class="is-size-7">→ Correo corporativo, CRM, otros.</span><br>
                              <i class="fas fa-check"></i> 7 días de promoción efectiva.<br>
                              <i class="fas fa-check"></i> Entrenamiento semanal.<br>
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide has-background-link has-text-light" id="slide7">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-8 is-offset-2">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">¿Más información?</h1>
                        <p>
                           Eleve su marca ¡estamos listos para empezar!
                        </p>
                        <a href="https://m.me/LlajwaClub" target="_blank" class="button is-white is-outlined  is-large">
                        <i class="fab fa-facebook-messenger"></i> &nbsp; Inicie un chat
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="section has-text-light" id="section6">
            <div class="slide" id="slide1">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h1 class="is-size-1-fullhd is-size-1-widescreen is-size-1-desktop is-size-2-touch is-size-2-tablet is-size-3-mobile">Laboratorio</h1>
                        <div class="column is-8 is-offset-2 is-size-4-fullhd is-size-4-widescreen is-size-4-desktop is-size-6-touch is-size-6-tablet is-size-7-mobile">  
                           <br>
                           ¿En qué estamos trabajando? 
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <h2 class="is-size-2-fullhd is-size-2-widescreen is-size-2-desktop is-size-3-touch is-size-3-tablet is-size-4-mobile">Ayudamos a crecer y escalar</h2>
                        <p>Ofrecemos potencia de cómputo, almacenamiento de bases de datos y entrega de 
                           contenidos. <br>Cree aplicaciones sofisticadas, flexibles, escalables y fiables.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide2">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <img src="imgs/logo-csd.png"><br>
                        <a class="button is-primary is-inverted is-outlined is-small"><i class="fas fa-home"></i> &nbsp; www.cochabamba.delivery</a><br><br>
                        <p>
                           Smart Delivery pretende que sus clientes y el servicio de logística de transporte interactuen a través de la nube.<br><br>
                           <span class="is-size-7">
                           <progress class="progress is-warning is-small" value="90" max="100">90%</progress>
                           90% implementado
                           </span>                     
                        </p>
                     </div>
                  </div>
                  <div class='carousel carousel-animated carousel-animate-slide' data-size="2" data-autoplay="true" data-delay="2000">
                     <div class='carousel-container'>
                        <div class='carousel-item is-active'>
                           <i class="fas fa-star"></i> Api Rest para sistemas externos.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Sistema de rastreo satelital inteligente.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estándares para integración con comercio electrónico.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Plataforma para envío de comida rápida.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Rediseño Web, personalización de redes sociales.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Aplicaciones móviles de uso interno y externo.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estrategía de promoción, publicidad CPA.
                        </div>
                     </div>
                     <div class="carousel-navigation is-centered">
                        <div class="carousel-nav-left">
                           <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-nav-right">
                           <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide3">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <img src="imgs/logo-pimienta.png"><br>
                        <a class="button is-primary is-inverted is-outlined is-small"><i class="fas fa-home"></i> &nbsp; www.pimienta.club</a><br><br>
                        <p>
                           Pimienta Club ofrece tecnología comercial para restaurantes y negocios similares a través de una enorme plataforma.<br><br>
                           <span class="is-size-7">
                           <progress class="progress is-warning is-small" value="75" max="100">75%</progress>
                           75% implementado
                           </span>                     
                        </p>
                     </div>
                  </div>
                  <div class='carousel carousel-animated carousel-animate-slide' data-size="2" data-autoplay="true" data-delay="2000">
                     <div class='carousel-container'>
                        <div class='carousel-item is-active'>
                           <i class="fas fa-star"></i> API Rest para sistemas externos.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Sistema de rastreo satelital inteligente.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estándares para integración con comercio electrónico.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Plataforma para envío de comida rápida.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Rediseño Web, personalización de redes sociales.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Aplicaciones móviles de uso interno y externo.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estrategía de promoción, publicidad CPA.
                        </div>
                     </div>
                     <div class="carousel-navigation is-centered">
                        <div class="carousel-nav-left">
                           <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-nav-right">
                           <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide4">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <img src="imgs/logo-facebook-baby.png"><br>
                        <a class="button is-primary is-inverted is-outlined is-small"><i class="fas fa-shopping-cart"></i> &nbsp; Ver en marketplace</a><br><br>
                        <p>
                           Pimienta Club ofrece tecnología comercial para restaurantes y negocios similares a través de una enorme plataforma.<br><br>
                           <span class="is-size-7">
                           <progress class="progress is-warning is-small" value="75" max="100">75%</progress>
                           75% implementado
                           </span>                     
                        </p>
                     </div>
                  </div>
                  <div class='carousel carousel-animated carousel-animate-slide' data-size="2" data-autoplay="true" data-delay="2000">
                     <div class='carousel-container'>
                        <div class='carousel-item is-active'>
                           <i class="fas fa-star"></i> API Rest para sistemas externos.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Sistema de rastreo satelital inteligente.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estándares para integración con comercio electrónico.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Plataforma para envío de comida rápida.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Rediseño Web, personalización de redes sociales.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Aplicaciones móviles de uso interno y externo.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estrategía de promoción, publicidad CPA.
                        </div>
                     </div>
                     <div class="carousel-navigation is-centered">
                        <div class="carousel-nav-left">
                           <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-nav-right">
                           <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide5">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <img src="imgs/logo-jumechi.png"><br>
                        <a class="button is-primary is-inverted is-outlined is-small"><i class="fas fa-shopping-cart"></i> &nbsp; Ver en marketplace</a><br><br>
                        <p>
                           Pimienta Club ofrece tecnología comercial para restaurantes y negocios similares a través de una enorme plataforma.<br><br>
                           <span class="is-size-7">
                           <progress class="progress is-warning is-small" value="75" max="100">75%</progress>
                           75% implementado
                           </span>                     
                        </p>
                     </div>
                  </div>
                  <div class='carousel carousel-animated carousel-animate-slide' data-size="2" data-autoplay="true" data-delay="2000">
                     <div class='carousel-container'>
                        <div class='carousel-item is-active'>
                           <i class="fas fa-star"></i> API Rest para sistemas externos.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Sistema de rastreo satelital inteligente.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estándares para integración con comercio electrónico.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Plataforma para envío de comida rápida.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Rediseño Web, personalización de redes sociales.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Aplicaciones móviles de uso interno y externo.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estrategía de promoción, publicidad CPA.
                        </div>
                     </div>
                     <div class="carousel-navigation is-centered">
                        <div class="carousel-nav-left">
                           <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-nav-right">
                           <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide6">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <img src="imgs/logo-llajwa-hub.png"><br>
                        <a class="button is-primary is-inverted is-outlined is-small"><i class="fas fa-shopping-cart"></i> &nbsp; Ver en marketplace</a><br><br>
                        <p>
                           Pimienta Club ofrece tecnología comercial para restaurantes y negocios similares a través de una enorme plataforma.<br><br>
                           <span class="is-size-7">
                           <progress class="progress is-warning is-small" value="75" max="100">75%</progress>
                           75% implementado
                           </span>                     
                        </p>
                     </div>
                  </div>
                  <div class='carousel carousel-animated carousel-animate-slide' data-size="2" data-autoplay="true" data-delay="2000">
                     <div class='carousel-container'>
                        <div class='carousel-item is-active'>
                           <i class="fas fa-star"></i> API Rest para sistemas externos.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Sistema de rastreo satelital inteligente.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estándares para integración con comercio electrónico.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Plataforma para envío de comida rápida.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Rediseño Web, personalización de redes sociales.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Aplicaciones móviles de uso interno y externo.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estrategía de promoción, publicidad CPA.
                        </div>
                     </div>
                     <div class="carousel-navigation is-centered">
                        <div class="carousel-nav-left">
                           <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-nav-right">
                           <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="slide" id="slide7">
               <div class="content">
                  <div class="columns is-mobile">
                     <div class="column is-10 is-offset-1">
                        <img src="imgs/logo-llajwa-work.png"><br>
                        <a class="button is-primary is-inverted is-outlined is-small"><i class="fas fa-shopping-cart"></i> &nbsp; Ver en marketplace</a><br><br>
                        <p>
                           Pimienta Club ofrece tecnología comercial para restaurantes y negocios similares a través de una enorme plataforma.<br><br>
                           <span class="is-size-7">
                           <progress class="progress is-warning is-small" value="75" max="100">75%</progress>
                           75% implementado
                           </span>                     
                        </p>
                     </div>
                  </div>
                  <div class='carousel carousel-animated carousel-animate-slide' data-size="2" data-autoplay="true" data-delay="2000">
                     <div class='carousel-container'>
                        <div class='carousel-item is-active'>
                           <i class="fas fa-star"></i> API Rest para sistemas externos.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Sistema de rastreo satelital inteligente.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estándares para integración con comercio electrónico.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Plataforma para envío de comida rápida.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Rediseño Web, personalización de redes sociales.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Aplicaciones móviles de uso interno y externo.
                        </div>
                        <div class='carousel-item'>
                           <i class="fas fa-star"></i> Estrategía de promoción, publicidad CPA.
                        </div>
                     </div>
                     <div class="carousel-navigation is-centered">
                        <div class="carousel-nav-left">
                           <i class="fa fa-chevron-left" aria-hidden="true"></i>
                        </div>
                        <div class="carousel-nav-right">
                           <i class="fa fa-chevron-right" aria-hidden="true"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script type="text/javascript" src="https://alvarotrigo.com/fullPage/vendors/scrolloverflow.js"></script>      
      <script type="text/javascript" src="../dist/fullpage.js"></script>
      <script type="text/javascript" src="https://wikiki.github.io/node_modules/bulma-extensions/bulma-carousel/dist/js/bulma-carousel.js"></script>
      <script type="text/javascript" src="js/aero.js"></script>
      <script src='//cdn.polyfill.io/v2/polyfill.min.js?features=es6,Array.prototype.includes,CustomEvent,Object.entries,Object.values,URL'></script>
      <script src='//unpkg.com/plyr@3'></script>
      <script  src="js/player.js"></script>      
   </body>
</html>